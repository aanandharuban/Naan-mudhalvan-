export interface Restaurant {
  id: string;
  name: string;
  description: string;
  cuisineType: string;
  priceRange: string;
  imageUrl: string;
  address: string;
  phone: string;
  rating: number;
  capacity: number;
  openingTime: string;
  closingTime: string;
  features: string[];
}

export interface Booking {
  id: string;
  restaurantId: string;
  guestName: string;
  guestEmail: string;
  guestPhone: string;
  bookingDate: string;
  bookingTime: string;
  partySize: number;
  specialRequests: string;
  occasion: string;
  status: 'pending' | 'confirmed' | 'cancelled' | 'completed';
}

export interface TimeSlot {
  time: string;
  available: boolean;
}
