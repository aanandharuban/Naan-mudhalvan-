import { Search, SlidersHorizontal, X } from 'lucide-react';

interface FilterBarProps {
  searchQuery: string;
  setSearchQuery: (query: string) => void;
  selectedCuisine: string;
  setSelectedCuisine: (cuisine: string) => void;
  selectedPriceRange: string;
  setSelectedPriceRange: (price: string) => void;
  showFilters: boolean;
  setShowFilters: (show: boolean) => void;
}

const cuisineTypes = ['All', 'French', 'Japanese', 'Italian', 'Steakhouse', 'Indian', 'Mediterranean'];
const priceRanges = ['All', '$$$', '$$$$'];

export function FilterBar({
  searchQuery,
  setSearchQuery,
  selectedCuisine,
  setSelectedCuisine,
  selectedPriceRange,
  setSelectedPriceRange,
  showFilters,
  setShowFilters
}: FilterBarProps) {
  const hasActiveFilters = selectedCuisine !== 'All' || selectedPriceRange !== 'All' || searchQuery !== '';

  const clearFilters = () => {
    setSearchQuery('');
    setSelectedCuisine('All');
    setSelectedPriceRange('All');
  };

  return (
    <div className="bg-white rounded-2xl shadow-lg p-6 mb-8">
      <div className="flex flex-col md:flex-row gap-4">
        <div className="flex-1 relative">
          <Search className="absolute left-4 top-1/2 transform -translate-y-1/2 text-gray-400 w-5 h-5" />
          <input
            type="text"
            placeholder="Search restaurants by name, cuisine, or location..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="w-full pl-12 pr-4 py-3.5 border border-gray-300 rounded-xl focus:ring-2 focus:ring-amber-500 focus:border-transparent transition-all"
          />
        </div>

        <button
          onClick={() => setShowFilters(!showFilters)}
          className={`px-6 py-3.5 rounded-xl font-semibold transition-all flex items-center gap-2 ${
            showFilters
              ? 'bg-amber-500 text-white shadow-md'
              : 'bg-gray-100 text-gray-700 hover:bg-gray-200'
          }`}
        >
          <SlidersHorizontal className="w-5 h-5" />
          Filters
          {hasActiveFilters && !showFilters && (
            <span className="bg-white text-amber-600 rounded-full w-5 h-5 flex items-center justify-center text-xs font-bold">
              !
            </span>
          )}
        </button>

        {hasActiveFilters && (
          <button
            onClick={clearFilters}
            className="px-6 py-3.5 bg-red-50 text-red-600 rounded-xl font-semibold hover:bg-red-100 transition-all flex items-center gap-2"
          >
            <X className="w-5 h-5" />
            Clear
          </button>
        )}
      </div>

      {showFilters && (
        <div className="mt-6 pt-6 border-t border-gray-200 grid md:grid-cols-2 gap-6">
          <div>
            <label className="block text-sm font-semibold text-gray-700 mb-3">
              Cuisine Type
            </label>
            <div className="flex flex-wrap gap-2">
              {cuisineTypes.map((cuisine) => (
                <button
                  key={cuisine}
                  onClick={() => setSelectedCuisine(cuisine)}
                  className={`px-4 py-2 rounded-lg font-medium transition-all ${
                    selectedCuisine === cuisine
                      ? 'bg-amber-500 text-white shadow-md'
                      : 'bg-gray-100 text-gray-700 hover:bg-gray-200'
                  }`}
                >
                  {cuisine}
                </button>
              ))}
            </div>
          </div>

          <div>
            <label className="block text-sm font-semibold text-gray-700 mb-3">
              Price Range
            </label>
            <div className="flex flex-wrap gap-2">
              {priceRanges.map((price) => (
                <button
                  key={price}
                  onClick={() => setSelectedPriceRange(price)}
                  className={`px-4 py-2 rounded-lg font-medium transition-all ${
                    selectedPriceRange === price
                      ? 'bg-amber-500 text-white shadow-md'
                      : 'bg-gray-100 text-gray-700 hover:bg-gray-200'
                  }`}
                >
                  {price}
                </button>
              ))}
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
