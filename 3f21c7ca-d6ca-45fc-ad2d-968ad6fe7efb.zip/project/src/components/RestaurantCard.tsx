import { Star, MapPin, Clock, DollarSign } from 'lucide-react';
import { Restaurant } from '../types';

interface RestaurantCardProps {
  restaurant: Restaurant;
  onBook: (restaurant: Restaurant) => void;
}

export function RestaurantCard({ restaurant, onBook }: RestaurantCardProps) {
  return (
    <div className="group bg-white rounded-2xl overflow-hidden shadow-lg hover:shadow-2xl transition-all duration-500 transform hover:-translate-y-2">
      <div className="relative h-64 overflow-hidden">
        <img
          src={restaurant.imageUrl}
          alt={restaurant.name}
          className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-700"
        />
        <div className="absolute top-4 right-4 bg-white/95 backdrop-blur-sm px-3 py-1.5 rounded-full flex items-center gap-1 shadow-lg">
          <Star className="w-4 h-4 fill-amber-400 text-amber-400" />
          <span className="font-semibold text-gray-800">{restaurant.rating}</span>
        </div>
        <div className="absolute top-4 left-4 bg-slate-900/90 backdrop-blur-sm px-3 py-1.5 rounded-full">
          <span className="text-white text-sm font-medium">{restaurant.cuisineType}</span>
        </div>
      </div>

      <div className="p-6">
        <div className="flex items-start justify-between mb-3">
          <h3 className="text-2xl font-bold text-gray-900 group-hover:text-amber-600 transition-colors">
            {restaurant.name}
          </h3>
          <div className="flex items-center text-amber-600 font-semibold">
            {restaurant.priceRange}
          </div>
        </div>

        <p className="text-gray-600 mb-4 line-clamp-2 leading-relaxed">
          {restaurant.description}
        </p>

        <div className="space-y-2 mb-4">
          <div className="flex items-center text-gray-500 text-sm">
            <MapPin className="w-4 h-4 mr-2 flex-shrink-0" />
            <span className="truncate">{restaurant.address}</span>
          </div>
          <div className="flex items-center text-gray-500 text-sm">
            <Clock className="w-4 h-4 mr-2 flex-shrink-0" />
            <span>{restaurant.openingTime} - {restaurant.closingTime}</span>
          </div>
        </div>

        <div className="flex flex-wrap gap-2 mb-5">
          {restaurant.features.slice(0, 3).map((feature, index) => (
            <span
              key={index}
              className="px-3 py-1 bg-slate-100 text-slate-700 text-xs font-medium rounded-full"
            >
              {feature}
            </span>
          ))}
          {restaurant.features.length > 3 && (
            <span className="px-3 py-1 bg-slate-100 text-slate-700 text-xs font-medium rounded-full">
              +{restaurant.features.length - 3} more
            </span>
          )}
        </div>

        <button
          onClick={() => onBook(restaurant)}
          className="w-full bg-gradient-to-r from-amber-500 to-amber-600 hover:from-amber-600 hover:to-amber-700 text-white font-semibold py-3.5 px-6 rounded-xl transition-all duration-300 shadow-md hover:shadow-xl transform hover:scale-105"
        >
          Reserve Table
        </button>
      </div>
    </div>
  );
}
