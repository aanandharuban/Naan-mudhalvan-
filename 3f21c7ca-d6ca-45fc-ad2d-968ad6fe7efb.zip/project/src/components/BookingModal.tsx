import { X, Calendar, Clock, Users, MessageSquare, Sparkles } from 'lucide-react';
import { useState } from 'react';
import { Restaurant, TimeSlot } from '../types';

interface BookingModalProps {
  restaurant: Restaurant | null;
  onClose: () => void;
  onConfirm: (bookingData: any) => void;
}

const occasions = [
  'Birthday',
  'Anniversary',
  'Business Dinner',
  'Date Night',
  'Celebration',
  'Family Gathering',
  'Other'
];

const partySizes = Array.from({ length: 12 }, (_, i) => i + 1);

export function BookingModal({ restaurant, onClose, onConfirm }: BookingModalProps) {
  const [formData, setFormData] = useState({
    guestName: '',
    guestEmail: '',
    guestPhone: '',
    bookingDate: '',
    bookingTime: '',
    partySize: 2,
    occasion: '',
    specialRequests: ''
  });

  const [errors, setErrors] = useState<Record<string, string>>({});

  if (!restaurant) return null;

  const generateTimeSlots = (): TimeSlot[] => {
    const slots: TimeSlot[] = [];
    const [openHour, openMinute] = restaurant.openingTime.split(':').map(Number);
    const [closeHour, closeMinute] = restaurant.closingTime.split(':').map(Number);

    let currentHour = openHour;
    let currentMinute = openMinute;

    while (currentHour < closeHour || (currentHour === closeHour && currentMinute <= closeMinute)) {
      const timeString = `${currentHour.toString().padStart(2, '0')}:${currentMinute.toString().padStart(2, '0')}`;
      slots.push({ time: timeString, available: true });

      currentMinute += 30;
      if (currentMinute >= 60) {
        currentMinute = 0;
        currentHour += 1;
      }
    }

    return slots;
  };

  const timeSlots = generateTimeSlots();

  const validateForm = () => {
    const newErrors: Record<string, string> = {};

    if (!formData.guestName.trim()) newErrors.guestName = 'Name is required';
    if (!formData.guestEmail.trim()) newErrors.guestEmail = 'Email is required';
    if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(formData.guestEmail)) newErrors.guestEmail = 'Invalid email format';
    if (!formData.guestPhone.trim()) newErrors.guestPhone = 'Phone is required';
    if (!formData.bookingDate) newErrors.bookingDate = 'Date is required';
    if (!formData.bookingTime) newErrors.bookingTime = 'Time is required';

    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();

    if (validateForm()) {
      onConfirm({
        ...formData,
        restaurantId: restaurant.id,
        restaurantName: restaurant.name,
        status: 'confirmed'
      });
    }
  };

  const today = new Date().toISOString().split('T')[0];

  return (
    <div className="fixed inset-0 bg-black/60 backdrop-blur-sm flex items-center justify-center z-50 p-4">
      <div className="bg-white rounded-3xl max-w-2xl w-full max-h-[90vh] overflow-y-auto shadow-2xl">
        <div className="sticky top-0 bg-gradient-to-r from-amber-500 to-amber-600 p-6 rounded-t-3xl z-10">
          <div className="flex items-start justify-between">
            <div>
              <h2 className="text-2xl font-bold text-white mb-1">{restaurant.name}</h2>
              <p className="text-amber-50">{restaurant.address}</p>
            </div>
            <button
              onClick={onClose}
              className="text-white hover:bg-white/20 rounded-full p-2 transition-colors"
            >
              <X className="w-6 h-6" />
            </button>
          </div>
        </div>

        <form onSubmit={handleSubmit} className="p-6 space-y-6">
          <div className="grid md:grid-cols-2 gap-6">
            <div>
              <label className="block text-sm font-semibold text-gray-700 mb-2">
                Full Name *
              </label>
              <input
                type="text"
                value={formData.guestName}
                onChange={(e) => setFormData({ ...formData, guestName: e.target.value })}
                className={`w-full px-4 py-3 border ${errors.guestName ? 'border-red-500' : 'border-gray-300'} rounded-xl focus:ring-2 focus:ring-amber-500 focus:border-transparent transition-all`}
                placeholder="John Doe"
              />
              {errors.guestName && <p className="text-red-500 text-xs mt-1">{errors.guestName}</p>}
            </div>

            <div>
              <label className="block text-sm font-semibold text-gray-700 mb-2">
                Email Address *
              </label>
              <input
                type="email"
                value={formData.guestEmail}
                onChange={(e) => setFormData({ ...formData, guestEmail: e.target.value })}
                className={`w-full px-4 py-3 border ${errors.guestEmail ? 'border-red-500' : 'border-gray-300'} rounded-xl focus:ring-2 focus:ring-amber-500 focus:border-transparent transition-all`}
                placeholder="john@example.com"
              />
              {errors.guestEmail && <p className="text-red-500 text-xs mt-1">{errors.guestEmail}</p>}
            </div>
          </div>

          <div>
            <label className="block text-sm font-semibold text-gray-700 mb-2">
              Phone Number *
            </label>
            <input
              type="tel"
              value={formData.guestPhone}
              onChange={(e) => setFormData({ ...formData, guestPhone: e.target.value })}
              className={`w-full px-4 py-3 border ${errors.guestPhone ? 'border-red-500' : 'border-gray-300'} rounded-xl focus:ring-2 focus:ring-amber-500 focus:border-transparent transition-all`}
              placeholder="(555) 123-4567"
            />
            {errors.guestPhone && <p className="text-red-500 text-xs mt-1">{errors.guestPhone}</p>}
          </div>

          <div className="grid md:grid-cols-2 gap-6">
            <div>
              <label className="block text-sm font-semibold text-gray-700 mb-2">
                <Calendar className="w-4 h-4 inline mr-1" />
                Date *
              </label>
              <input
                type="date"
                min={today}
                value={formData.bookingDate}
                onChange={(e) => setFormData({ ...formData, bookingDate: e.target.value })}
                className={`w-full px-4 py-3 border ${errors.bookingDate ? 'border-red-500' : 'border-gray-300'} rounded-xl focus:ring-2 focus:ring-amber-500 focus:border-transparent transition-all`}
              />
              {errors.bookingDate && <p className="text-red-500 text-xs mt-1">{errors.bookingDate}</p>}
            </div>

            <div>
              <label className="block text-sm font-semibold text-gray-700 mb-2">
                <Users className="w-4 h-4 inline mr-1" />
                Party Size *
              </label>
              <select
                value={formData.partySize}
                onChange={(e) => setFormData({ ...formData, partySize: Number(e.target.value) })}
                className="w-full px-4 py-3 border border-gray-300 rounded-xl focus:ring-2 focus:ring-amber-500 focus:border-transparent transition-all"
              >
                {partySizes.map(size => (
                  <option key={size} value={size}>
                    {size} {size === 1 ? 'Guest' : 'Guests'}
                  </option>
                ))}
              </select>
            </div>
          </div>

          <div>
            <label className="block text-sm font-semibold text-gray-700 mb-2">
              <Clock className="w-4 h-4 inline mr-1" />
              Preferred Time *
            </label>
            <div className="grid grid-cols-4 gap-2 max-h-48 overflow-y-auto p-2 border border-gray-200 rounded-xl">
              {timeSlots.map((slot) => (
                <button
                  key={slot.time}
                  type="button"
                  onClick={() => setFormData({ ...formData, bookingTime: slot.time })}
                  className={`px-4 py-2.5 rounded-lg font-medium transition-all ${
                    formData.bookingTime === slot.time
                      ? 'bg-amber-500 text-white shadow-md'
                      : 'bg-gray-100 text-gray-700 hover:bg-gray-200'
                  }`}
                >
                  {slot.time}
                </button>
              ))}
            </div>
            {errors.bookingTime && <p className="text-red-500 text-xs mt-1">{errors.bookingTime}</p>}
          </div>

          <div>
            <label className="block text-sm font-semibold text-gray-700 mb-2">
              <Sparkles className="w-4 h-4 inline mr-1" />
              Special Occasion
            </label>
            <select
              value={formData.occasion}
              onChange={(e) => setFormData({ ...formData, occasion: e.target.value })}
              className="w-full px-4 py-3 border border-gray-300 rounded-xl focus:ring-2 focus:ring-amber-500 focus:border-transparent transition-all"
            >
              <option value="">Select an occasion (optional)</option>
              {occasions.map(occasion => (
                <option key={occasion} value={occasion}>{occasion}</option>
              ))}
            </select>
          </div>

          <div>
            <label className="block text-sm font-semibold text-gray-700 mb-2">
              <MessageSquare className="w-4 h-4 inline mr-1" />
              Special Requests
            </label>
            <textarea
              value={formData.specialRequests}
              onChange={(e) => setFormData({ ...formData, specialRequests: e.target.value })}
              rows={4}
              className="w-full px-4 py-3 border border-gray-300 rounded-xl focus:ring-2 focus:ring-amber-500 focus:border-transparent transition-all resize-none"
              placeholder="Dietary restrictions, seating preferences, allergies..."
            />
          </div>

          <div className="flex gap-4 pt-4">
            <button
              type="button"
              onClick={onClose}
              className="flex-1 px-6 py-3.5 border-2 border-gray-300 text-gray-700 font-semibold rounded-xl hover:bg-gray-50 transition-all"
            >
              Cancel
            </button>
            <button
              type="submit"
              className="flex-1 px-6 py-3.5 bg-gradient-to-r from-amber-500 to-amber-600 hover:from-amber-600 hover:to-amber-700 text-white font-semibold rounded-xl transition-all shadow-lg hover:shadow-xl transform hover:scale-105"
            >
              Confirm Reservation
            </button>
          </div>
        </form>
      </div>
    </div>
  );
}
