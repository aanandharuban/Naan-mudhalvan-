import { CheckCircle2, Calendar, Clock, Users, MapPin, Phone, Mail, X } from 'lucide-react';

interface ConfirmationModalProps {
  bookingData: any;
  onClose: () => void;
}

export function ConfirmationModal({ bookingData, onClose }: ConfirmationModalProps) {
  if (!bookingData) return null;

  const formatDate = (dateString: string) => {
    const date = new Date(dateString);
    return date.toLocaleDateString('en-US', {
      weekday: 'long',
      year: 'numeric',
      month: 'long',
      day: 'numeric'
    });
  };

  return (
    <div className="fixed inset-0 bg-black/60 backdrop-blur-sm flex items-center justify-center z-50 p-4">
      <div className="bg-white rounded-3xl max-w-lg w-full shadow-2xl overflow-hidden">
        <div className="bg-gradient-to-br from-green-500 to-emerald-600 p-8 text-center relative">
          <button
            onClick={onClose}
            className="absolute top-4 right-4 text-white/80 hover:text-white hover:bg-white/20 rounded-full p-2 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
          <div className="flex justify-center mb-4">
            <div className="bg-white rounded-full p-3 shadow-lg">
              <CheckCircle2 className="w-16 h-16 text-green-500" />
            </div>
          </div>
          <h2 className="text-3xl font-bold text-white mb-2">Reservation Confirmed!</h2>
          <p className="text-green-50">Your table has been successfully reserved</p>
        </div>

        <div className="p-8 space-y-6">
          <div className="bg-amber-50 border-2 border-amber-200 rounded-2xl p-6">
            <h3 className="text-xl font-bold text-gray-900 mb-4">{bookingData.restaurantName}</h3>

            <div className="space-y-3">
              <div className="flex items-center text-gray-700">
                <Calendar className="w-5 h-5 text-amber-600 mr-3 flex-shrink-0" />
                <span className="font-medium">{formatDate(bookingData.bookingDate)}</span>
              </div>

              <div className="flex items-center text-gray-700">
                <Clock className="w-5 h-5 text-amber-600 mr-3 flex-shrink-0" />
                <span className="font-medium">{bookingData.bookingTime}</span>
              </div>

              <div className="flex items-center text-gray-700">
                <Users className="w-5 h-5 text-amber-600 mr-3 flex-shrink-0" />
                <span className="font-medium">
                  {bookingData.partySize} {bookingData.partySize === 1 ? 'Guest' : 'Guests'}
                </span>
              </div>
            </div>
          </div>

          <div className="space-y-3 border-t border-gray-200 pt-6">
            <h4 className="font-semibold text-gray-900 text-sm uppercase tracking-wide">Guest Information</h4>

            <div className="flex items-center text-gray-600">
              <Users className="w-4 h-4 text-gray-400 mr-3 flex-shrink-0" />
              <span>{bookingData.guestName}</span>
            </div>

            <div className="flex items-center text-gray-600">
              <Mail className="w-4 h-4 text-gray-400 mr-3 flex-shrink-0" />
              <span>{bookingData.guestEmail}</span>
            </div>

            <div className="flex items-center text-gray-600">
              <Phone className="w-4 h-4 text-gray-400 mr-3 flex-shrink-0" />
              <span>{bookingData.guestPhone}</span>
            </div>

            {bookingData.occasion && (
              <div className="flex items-start text-gray-600">
                <span className="text-gray-400 mr-3 flex-shrink-0 text-sm">Occasion:</span>
                <span className="font-medium">{bookingData.occasion}</span>
              </div>
            )}

            {bookingData.specialRequests && (
              <div className="flex items-start text-gray-600">
                <span className="text-gray-400 mr-3 flex-shrink-0 text-sm">Notes:</span>
                <span className="italic">{bookingData.specialRequests}</span>
              </div>
            )}
          </div>

          <div className="bg-slate-50 rounded-xl p-4 text-sm text-gray-600">
            <p className="leading-relaxed">
              A confirmation email has been sent to <span className="font-semibold">{bookingData.guestEmail}</span>.
              Please arrive 10 minutes before your reservation time.
            </p>
          </div>

          <button
            onClick={onClose}
            className="w-full bg-gradient-to-r from-amber-500 to-amber-600 hover:from-amber-600 hover:to-amber-700 text-white font-semibold py-4 px-6 rounded-xl transition-all shadow-lg hover:shadow-xl transform hover:scale-105"
          >
            Done
          </button>
        </div>
      </div>
    </div>
  );
}
