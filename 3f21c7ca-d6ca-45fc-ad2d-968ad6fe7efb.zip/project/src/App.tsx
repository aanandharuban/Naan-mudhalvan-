import { useState } from 'react';
import { Utensils, Sparkles } from 'lucide-react';
import { restaurants } from './data/restaurants';
import { Restaurant } from './types';
import { RestaurantCard } from './components/RestaurantCard';
import { BookingModal } from './components/BookingModal';
import { ConfirmationModal } from './components/ConfirmationModal';
import { FilterBar } from './components/FilterBar';

function App() {
  const [selectedRestaurant, setSelectedRestaurant] = useState<Restaurant | null>(null);
  const [bookingData, setBookingData] = useState<any>(null);
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedCuisine, setSelectedCuisine] = useState('All');
  const [selectedPriceRange, setSelectedPriceRange] = useState('All');
  const [showFilters, setShowFilters] = useState(false);

  const handleBooking = (restaurant: Restaurant) => {
    setSelectedRestaurant(restaurant);
  };

  const handleConfirmBooking = (data: any) => {
    setBookingData(data);
    setSelectedRestaurant(null);
  };

  const filteredRestaurants = restaurants.filter((restaurant) => {
    const matchesSearch =
      restaurant.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
      restaurant.cuisineType.toLowerCase().includes(searchQuery.toLowerCase()) ||
      restaurant.address.toLowerCase().includes(searchQuery.toLowerCase()) ||
      restaurant.description.toLowerCase().includes(searchQuery.toLowerCase());

    const matchesCuisine =
      selectedCuisine === 'All' || restaurant.cuisineType === selectedCuisine;

    const matchesPrice =
      selectedPriceRange === 'All' || restaurant.priceRange === selectedPriceRange;

    return matchesSearch && matchesCuisine && matchesPrice;
  });

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-50 via-amber-50 to-slate-50">
      <header className="bg-gradient-to-r from-slate-900 to-slate-800 text-white shadow-2xl sticky top-0 z-40">
        <div className="container mx-auto px-4 py-6">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-3">
              <div className="bg-amber-500 rounded-2xl p-3 shadow-lg">
                <Utensils className="w-8 h-8" />
              </div>
              <div>
                <h1 className="text-3xl font-bold tracking-tight">LuxeDine</h1>
                <p className="text-slate-300 text-sm">Reserve Your Perfect Table</p>
              </div>
            </div>
            <div className="hidden md:flex items-center gap-2 bg-white/10 backdrop-blur-sm px-4 py-2 rounded-full">
              <Sparkles className="w-4 h-4 text-amber-400" />
              <span className="text-sm font-medium">Premium Dining Experience</span>
            </div>
          </div>
        </div>
      </header>

      <main className="container mx-auto px-4 py-12">
        <div className="text-center mb-12">
          <h2 className="text-4xl md:text-5xl font-bold text-gray-900 mb-4">
            Discover Exquisite Dining
          </h2>
          <p className="text-xl text-gray-600 max-w-2xl mx-auto">
            Book a table at the finest restaurants in the city. Luxury, elegance, and unforgettable experiences await.
          </p>
        </div>

        <FilterBar
          searchQuery={searchQuery}
          setSearchQuery={setSearchQuery}
          selectedCuisine={selectedCuisine}
          setSelectedCuisine={setSelectedCuisine}
          selectedPriceRange={selectedPriceRange}
          setSelectedPriceRange={setSelectedPriceRange}
          showFilters={showFilters}
          setShowFilters={setShowFilters}
        />

        {filteredRestaurants.length === 0 ? (
          <div className="text-center py-16">
            <div className="bg-white rounded-2xl shadow-lg p-12 max-w-md mx-auto">
              <div className="text-gray-400 mb-4">
                <Utensils className="w-16 h-16 mx-auto" />
              </div>
              <h3 className="text-2xl font-bold text-gray-900 mb-2">No restaurants found</h3>
              <p className="text-gray-600">Try adjusting your search or filters to find more options.</p>
            </div>
          </div>
        ) : (
          <>
            <div className="mb-6 text-gray-600 font-medium">
              Showing {filteredRestaurants.length} {filteredRestaurants.length === 1 ? 'restaurant' : 'restaurants'}
            </div>
            <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
              {filteredRestaurants.map((restaurant) => (
                <RestaurantCard
                  key={restaurant.id}
                  restaurant={restaurant}
                  onBook={handleBooking}
                />
              ))}
            </div>
          </>
        )}
      </main>

      <footer className="bg-slate-900 text-white mt-20">
        <div className="container mx-auto px-4 py-12">
          <div className="grid md:grid-cols-3 gap-8 mb-8">
            <div>
              <div className="flex items-center gap-2 mb-4">
                <div className="bg-amber-500 rounded-xl p-2">
                  <Utensils className="w-6 h-6" />
                </div>
                <span className="text-2xl font-bold">LuxeDine</span>
              </div>
              <p className="text-slate-400">
                Your gateway to the finest dining experiences. Reserve tables at premium restaurants with ease.
              </p>
            </div>
            <div>
              <h3 className="font-bold text-lg mb-4">Quick Links</h3>
              <ul className="space-y-2 text-slate-400">
                <li><a href="#" className="hover:text-amber-400 transition-colors">About Us</a></li>
                <li><a href="#" className="hover:text-amber-400 transition-colors">Featured Restaurants</a></li>
                <li><a href="#" className="hover:text-amber-400 transition-colors">How It Works</a></li>
                <li><a href="#" className="hover:text-amber-400 transition-colors">Contact</a></li>
              </ul>
            </div>
            <div>
              <h3 className="font-bold text-lg mb-4">Support</h3>
              <ul className="space-y-2 text-slate-400">
                <li><a href="#" className="hover:text-amber-400 transition-colors">Help Center</a></li>
                <li><a href="#" className="hover:text-amber-400 transition-colors">Terms of Service</a></li>
                <li><a href="#" className="hover:text-amber-400 transition-colors">Privacy Policy</a></li>
                <li><a href="#" className="hover:text-amber-400 transition-colors">Partner With Us</a></li>
              </ul>
            </div>
          </div>
          <div className="border-t border-slate-800 pt-8 text-center text-slate-400">
            <p>&copy; 2025 LuxeDine. All rights reserved. Experience luxury dining at its finest.</p>
          </div>
        </div>
      </footer>

      {selectedRestaurant && (
        <BookingModal
          restaurant={selectedRestaurant}
          onClose={() => setSelectedRestaurant(null)}
          onConfirm={handleConfirmBooking}
        />
      )}

      {bookingData && (
        <ConfirmationModal
          bookingData={bookingData}
          onClose={() => setBookingData(null)}
        />
      )}
    </div>
  );
}

export default App;
